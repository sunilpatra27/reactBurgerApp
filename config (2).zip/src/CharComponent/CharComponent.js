import React ,{Component} from 'react';

class CharComponent extends Component{

    render(){

        const style={

            display:"inline-block",
            padding:"16px",
            textAlign:"center",
            margin:'16px',
            border:'1px solid black'


        }
        return(

<div style={style} >

<h3>Char component</h3>


<input type="text"
                 placeholder="name"
              onChange={this.props.charchanged}
                
                 value={this.props.value}/>

                 <p>
                     {this.props.value}
                 </p>

                 <button onClick={this.props.click}>Delete Char</button>


</div>




        )
    }
}

export default CharComponent;