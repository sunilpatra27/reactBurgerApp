import React ,{Component} from 'react';

class UserInput extends Component{


    
    render(){
        const style={
            border:'2px solid red',
        };
        return(

            <div className='User-input-output' >

                <input type="text"
                 placeholder="name"
                 style={style} 
                 onChange={this.props.changed} 
                 value={this.props.currentName}/>

            </div>
        )
    }
}

export default UserInput;