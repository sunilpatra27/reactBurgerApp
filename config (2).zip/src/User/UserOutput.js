import React ,{Component} from 'react';

class UserOutput extends Component{


    render(){

        return(
            <div className='User-input-output'>

          
        User Name: {this.props.userName}
            </div>

        )
    }
}

export default UserOutput;