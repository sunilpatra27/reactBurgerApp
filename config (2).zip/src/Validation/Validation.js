import React,{Component} from 'react';

class Validation extends Component{

    render(){

        return(
            <div>
        <div>Here is the validation componenet </div>

        {this.props.inputTextLength}

        {
            (this.props.inputTextLength<5)?
            <p>Text Is too short</p>:

            (this.props.inputTextLength===5)?

            <p>Text is ok</p>:

            <p>Text is too long</p>




        }

</div>
        );
    }

}


export  default Validation;