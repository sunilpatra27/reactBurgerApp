import axios from 'axios';

const insatnce=axios.create({
    baseURL:'https://react-my-burger-27.firebaseio.com'
})


export default insatnce;