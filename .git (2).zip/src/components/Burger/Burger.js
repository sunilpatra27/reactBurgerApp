
import React from 'react';

import classes from './Burger.css';
import BurgerIngredient from './BurgerIngredient/BurgerIngredient';
// import {withRouter} from 'react-router-dom';
const Burger =(props)=>{

    console.log(props);
    let transformedIngeredients=Object.keys(props.ingeredients)
    .map(igKey=>{

        return [...Array(props.ingeredients[igKey])].map((_,i)=>{

           return <BurgerIngredient key={igKey+i} type={igKey}/> 

        });
    })
    .reduce((arr,el)=>{

        return arr.concat(el)
    },[]);
    if(transformedIngeredients.length===0){
        transformedIngeredients=<p>Please start adding ingeredients!</p>
    }
//console.log(transformedIngeredients);
    return(

        <div className={classes.Burger}>

        <BurgerIngredient type="bread-top"/>
        {transformedIngeredients}
        <BurgerIngredient type="bread-bottom"/>
    

        </div>
    );
};

// export default withRouter(Burger);

export default Burger;