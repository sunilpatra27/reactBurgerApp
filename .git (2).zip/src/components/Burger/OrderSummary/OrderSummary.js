import React,{Component} from 'react';

import Auxiliary from '../../../hoc/Auxiliary/Auxiliary';
import Button from '../../UI/Button/Button';
class  OrderSummary extends Component{
    
componentWillUpdate(){
    console.log("order summary upadted");
}
render(){
    const ingridentSummary=Object.keys(this.props.ingeredients)
    .map(igKey=>{
        return <li key={igKey}>
            <span style={{textTransform:'capitalize'}}>{igKey}</span>:{this.props.ingeredients[igKey]}
            </li>
    })
    ;

return(
    <Auxiliary>

        <h3>Your Order</h3>

        <p>A delicious burger with the following ingridents</p>

        <ul>

            {ingridentSummary}
        </ul>


        <p><strong>Total Price:{this.props.price}</strong></p>

        <Button btnType="Danger" clicked={this.props.purchaseCancelled}>CANCEL</Button>
        <Button btnType="Success" clicked={this.props.purchaseContinued}>CONTINUE</Button>

    </Auxiliary>
)
}

};

export default OrderSummary;