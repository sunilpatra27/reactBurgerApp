import React from 'react';
import classes from './Order.css';
const order=(props)=>{

    const ingeredients=[];

    for(let ingeredientName in props.ingeredients ){

        ingeredients.push({

            name:ingeredientName,
            amount:props.ingeredients[ingeredientName]

        })
    }

    const ingeredientsOutPut=ingeredients.map(ig=>{


        return <span style={{
            textTransform:'capitalize',
            padding:'5px',
            margin:'0px 8px',
            display:'inline-block',
            border:'1px solid #ccc'}}
         key={ig.name}>{ig.name}:{ig.amount}</span>
    }

    )

    return(
        <div className={classes.Order}>

            <p>ingeredients :{ingeredientsOutPut}</p>
            <p>Price: <strong>{Number.parseFloat(props.price).toFixed(2)}</strong></p>
        </div>
    )
}



export default order;