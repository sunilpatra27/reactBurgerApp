import React,{Component} from 'react';

import Order from '../../components/Order/CheckoutSummary/Order';
import axios from '../../order-axios';
import withErrorHandler from '../../hoc/withErrorHandler/withErrorHandler';
class Orders extends Component{


    state={
        loading:true,

        orders:[]
    }

    componentDidMount(){

        axios.get('/order.json').then(response=>{

            const fetchOrders=[];
            console.log(response.data);
            for(let key in response.data){

                fetchOrders.push({
                    ...response.data[key],
                    id:key
                })
            }
            this.setState({ loading:false, orders:fetchOrders});

        })
        .catch(err=>{
            this.setState({loading:false});
        })
    }

 render(){


    return (

        <div>
            {this.state.orders.map(order=>(
                <Order key={order.id}
                
                ingeredients={order.ingredients}
                price={order.price}/>
            ))}


        </div>

    )
 }













}








export default withErrorHandler(Orders,axios);