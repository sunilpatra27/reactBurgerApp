import React, { Component } from 'react';
import Auxilary from '../../hoc/Auxiliary/Auxiliary';
import Burger from '../../components/Burger/Burger';
import BuildControls from '../../components/Burger/BuildControls/BuildControls';
import Modal from '../../components/UI/Modal/Modal';
import OdrderSummary from '../../components/Burger/OrderSummary/OrderSummary';
import axios from '../../order-axios';
import Spinner from '../../components/UI/Spinner/Spinner';
import withErrorHandler from '../../hoc/withErrorHandler/withErrorHandler';
const INGREDIENT_PRICES={

    salad : 11,
    cheese:10,
    meat:25,
    bacon:5


}

class BurgerBuilder extends Component{


    state={
        ingeredients:null,

        totalPrice:49,
        purchaseable:false,
        puchasing:false,
        loading:false,
        error:false
    }

    componentDidMount(){

        axios.get("https://react-my-burger-27.firebaseio.com/ingeredients.json").then(response=>{
            this.setState({ingeredients:response.data});
        })
        .catch(error=>{
            this.setState({error:true});
        })
    }
    render(){

        const disableInfo={
            ...this.state.ingeredients
        }
        for(let key in disableInfo ){

            disableInfo[key]=disableInfo[key]<=0;
        }
        let orderSummary=null;
        if(this.state.ingeredients){
            
        }
        
       
        let burger=this.state.error ?<p>Ingredienets Can't be loaded</p>: <Spinner/>;
        if(this.state.ingeredients){
            burger=(<Auxilary>
            <Burger  ingeredients={this.state.ingeredients}/>

                   <BuildControls  
                   ingridentAdded={this.addIngredientHandler}
                       
                   ingridentRemoved={this.removeIngredientHandler}
                       
                   disabled={disableInfo}
                   price={this.state.totalPrice}
                   purchaseable={this.state.purchaseable}
                   orderd={this.purchaseHandeler}
/>
       </Auxilary>);

orderSummary=<OdrderSummary ingeredients={this.state.ingeredients} 
purchaseCancelled={this.purchaseCancelHandeler}
purchaseContinued={this.purchaseContinueHandeler}
price={this.state.totalPrice}/>


        }
        if(this.state.loading){

            orderSummary=<Spinner/>

        }

        return(

            <Auxilary>
                 <Modal show={this.state.puchasing} modalClosed={this.purchaseCancelHandeler}>

                     {orderSummary}
                 </Modal>
               {burger}
            </Auxilary>

           

        );
    }
    purchaseCancelHandeler=()=>{

        this.setState({puchasing:false});

        
    }

    purchaseContinueHandeler=()=>{

      //  alert("Purchase Continued");
    //   this.setState({loading:true});

    //     const order={
    //         ingredients:this.state.ingeredients,
    //         price:this.state.totalPrice,
    //         customer:{
    //             name:"Sunil Patra",
    //             address:{
    //                 street:'NPT',
    //                 zipCode:"464654",
    //                 country:"India"
    //             },
    //             email:"sunil@gmail.com",

    //         },
    //         deliveryMethod:'Fastest'
    //     }

    //     axios.post('/order.json',order).then(response=>{
    //         this.setState({loading:false,puchasing:false});
    //     })

    //     .catch(error=>{
    //         console.log(error);
    //         this.setState({loading:false,puchasing:false});
    //     });
    

    // var queryStringIngredients = Object.keys(this.state.ingeredients)
    // .map(key => key + '=' + this.state.ingeredients[key]).join('&');
    //   this.props.history.push({
    //     pathname: '/checkout',
    //     search: `?${queryStringIngredients}`
    //   })
    const queryParams = [];
        for (let i in this.state.ingeredients) {
            queryParams.push(encodeURIComponent(i) + '=' + encodeURIComponent(this.state.ingeredients[i]));
        }

        queryParams.push('price=' + this.state.totalPrice);
        const queryString = queryParams.join('&');
        this.props.history.push({
            pathname: '/checkout',
            search: '?' + queryString
        });
    }
    purchaseHandeler=()=>{

        this.setState({puchasing:true})
    }
    updatePurchaceState(ingredients){

       
        const sum=Object.keys(ingredients)
        .map(igKey=>{
            return ingredients[igKey];
        })
        .reduce((sum,el)=>{
            return sum+el;

        },0);
      //  Object.values(ingeredients).reduce((sum, e)=> return sum+e);
        this.setState({purchaseable:sum>0});

    }
    addIngredientHandler=(type)=>{


        const oldCount=this.state.ingeredients[type];
        const updatedCount=oldCount+1;
        const updatedIngerdiants={
            ...this.state.ingeredients
        };
        updatedIngerdiants[type]=updatedCount;
        const priceAddition=INGREDIENT_PRICES[type];
        const oldPrice=this.state.totalPrice;
        const newPrice=oldPrice+priceAddition;
        this.setState({totalPrice:newPrice,ingeredients:updatedIngerdiants})
        this.updatePurchaceState(updatedIngerdiants);
    
    }
    removeIngredientHandler=(type)=>{
        const oldCount=this.state.ingeredients[type];
        if(oldCount<=0){
            return;
        }
        const updatedCount=oldCount-1;
        const updatedIngerdiants={
            ...this.state.ingeredients
        };
        updatedIngerdiants[type]=updatedCount;
        const priceAddition=INGREDIENT_PRICES[type];
        const oldPrice=this.state.totalPrice;
        const newPrice=oldPrice-priceAddition;
        this.setState({totalPrice:newPrice,ingeredients:updatedIngerdiants})
        this.updatePurchaceState(updatedIngerdiants);
    }


}


export default withErrorHandler(BurgerBuilder,axios);