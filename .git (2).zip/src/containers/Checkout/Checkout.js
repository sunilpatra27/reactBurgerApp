import React,{Component} from 'react';
import CheckoutSummary from '../../components/Order/CheckoutSummary/CheckoutSummary';
import ContactData from './ContactData/ContactData';
import {Route} from 'react-router-dom';




class Checkout extends Component{

    state={

        ingeredients:null
        ,totalPrice:0
    }
render(){

    return(

        <div>
            <CheckoutSummary 
            ingeredients={this.state.ingeredients}
            checkoutContinued={this.checkoutContinuedHandeler}
            checkoutCanceled={this.checkoutCanceledHandeler}
            />

            <Route path={this.props.match.path + '/contact-data'} render={(props)=>(<ContactData ingeredients={this.state.ingeredients} totalPrice={this.state.totalPrice} {...props}/>)}/>
        </div>
    );
}

checkoutContinuedHandeler=()=>{

    this.props.history.replace("/checkout/contact-data");

}

checkoutCanceledHandeler=()=>{
    this.props.history.goBack();
}

componentWillMount(){
    // const ingredientsParams  =new URLSearchParams(this.props.location.search);
    // const ingredientsObject = {};
    //     ingredientsParams.forEach((val, key) => {
    //         ingredientsObject[key] = +val;
    //     })
    //     this.setState({ingeredients: ingredientsObject});

    const query = new URLSearchParams(this.props.location.search);
        const ingredients = {};
        let price=0;
        for (let param of query.entries()) {
            // ['salad', '1']

            if(param[0]==='price'){
                price=param[1];
            }
            else{
            ingredients[param[0]] = +param[1];
            }
        }
        this.setState({ingeredients: ingredients,totalPrice:price});
}

}


export default Checkout;
