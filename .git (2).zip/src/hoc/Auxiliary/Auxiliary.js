const auxiliary=(props)=>props.children;

export default auxiliary